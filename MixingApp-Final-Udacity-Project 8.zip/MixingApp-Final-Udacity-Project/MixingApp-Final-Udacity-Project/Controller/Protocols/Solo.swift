//
//  Solo.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-04-21.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import Foundation

extension TracksViewController: Solo {
    
    func soloButtonTapped(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was soloed!")
        cell.isMuted = false
        cell.audioPlayer?.volume = cell.volumeSlider.value
        cell.muteButton.tintColor = .clear
        cell.muteButton.backgroundColor = .clear
        cell.muteButton.alpha = 0.7
        cell.muteButton.isEnabled = false
        cell.muteButton.isSelected = false
        soloIndexPath.remove(at: indexPath!.row)
        soloIndexPath.insert(indexPath, at: indexPath!.row)
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["solo" : true])
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : false])
        print("SOLO INDEX: \(soloIndexPath)")
        for item in 0..<collectionView.numberOfItems(inSection: 0) where item != soloIndexPath[item]?.row {
            let indexPaths = IndexPath(item: item, section: 0)
            if let cell = collectionView.cellForItem(at: indexPaths) as? TrackCell {
                cell.isMuted = true
                cell.audioPlayer?.volume = 0
                cell.muteButton.tintColor = .muteBlue
                cell.muteButton.backgroundColor = .muteBlue
                cell.muteButton.alpha = 0.7
                cell.muteButton.isEnabled = false
                cell.muteButton.isSelected = false
                projectRef.child("track\(indexPaths.row)").updateChildValues(["mute" : true])
            }
        }
    }
    
    func soloButtonTappedAgain(cell: TrackCell) {
        let indexPath = self.collectionView.indexPath(for: cell)
        index = indexPath
        print(index ?? 0)
        print("Track \(indexPath?.row ?? 0) was unsoloed!")
        cell.isMuted = true
        cell.audioPlayer?.volume = 0
        cell.muteButton.tintColor = .muteBlue
        cell.muteButton.backgroundColor = .muteBlue
        cell.muteButton.alpha = 0.7
        cell.muteButton.isEnabled = false
        soloIndexPath.remove(at: indexPath!.row)
        soloIndexPath.insert(nil, at: indexPath!.row)
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["solo" : false])
        projectRef.child("track\(indexPath?.row ?? 0)").updateChildValues(["mute" : true])
        print("SOLO INDEX: \(soloIndexPath)")
        if soloIndexPath.allEqualTo(value: nil) {
            for item in 0..<collectionView.numberOfItems(inSection: 0) {
                let indexPaths = IndexPath(item: item, section: 0)
                if let cell = collectionView.cellForItem(at: indexPaths) as? TrackCell {
                    cell.isMuted = false
                    cell.audioPlayer?.volume = cell.volumeSlider.value
                    cell.muteButton.tintColor = .clear
                    cell.muteButton.backgroundColor = .clear
                    cell.muteButton.alpha = 1.0
                    cell.muteButton.isEnabled = true
                    projectRef.child("track\(indexPaths.row)").updateChildValues(["mute" : false])
                }
            }
        }
    }
    
}

extension Array where Element: Equatable {
    func allEqualTo(value: Element) -> Bool {
        return !contains { $0 != value}
    }
}
