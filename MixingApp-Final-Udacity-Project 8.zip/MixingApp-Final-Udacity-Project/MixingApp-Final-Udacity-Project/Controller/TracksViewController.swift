//
//  ViewController.swift
//  MixingApp-Final-Udacity-Project
//
//  Created by Kyle Wilson on 2020-03-27.
//  Copyright © 2020 Xcode Tips. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices
import Firebase

class TracksViewController: UIViewController {
    
    var userID: String?
    
    var projectKey: String?
    
    var trackAmount: Int?
    
    var dict = [String : Any]()
    
    var tracks = [Track]()
    
    var ref: DatabaseReference!
    
    var projectRef: DatabaseReference!
    
    
    var dataController: DataController!
    
    var readValuesFromDatabase = [Bool](repeating: false, count: 6)
    
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var goBackToStartButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    
    
    @IBOutlet weak var progressLoading: UIProgressView!
    
    @IBOutlet weak var uploadingAudioLabel: UILabel!
    
    @IBOutlet weak var loadingProjectIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var knob1: Knob!
    @IBOutlet weak var knob2: Knob!
    @IBOutlet weak var knob3: Knob!
    @IBOutlet weak var knob4: Knob!
    @IBOutlet weak var knob5: Knob!
    @IBOutlet weak var knob6: Knob!
    @IBOutlet weak var knob7: Knob!
    @IBOutlet weak var knob8: Knob!
    
    @IBOutlet weak var knob1ValueLabel: UILabel!
    @IBOutlet weak var knob2ValueLabel: UILabel!
    @IBOutlet weak var knob3ValueLabel: UILabel!
    @IBOutlet weak var knob4ValueLabel: UILabel!
    @IBOutlet weak var knob5ValueLabel: UILabel!
    @IBOutlet weak var knob6ValueLabel: UILabel!
    @IBOutlet weak var knob7ValueLabel: UILabel!
    @IBOutlet weak var knob8ValueLabel: UILabel!
    
    @IBOutlet weak var trackName: UILabel!
    
    let queue = DispatchQueue(label: "Serial queue")
    
    var knobs: [Knob] = []
    
    var audioEngine: AVAudioEngine = AVAudioEngine()
    var mixer: AVAudioMixerNode = AVAudioMixerNode()
    var audioPlayers = [AVAudioPlayerNode?](repeating: nil, count: 6)
    var equalizers = [AVAudioUnitEQ?](repeating: nil, count: 6)
    
    var soloIndexPath = [IndexPath?](repeating: nil, count: 6)
    
    var startSeconds: Int64!
    var currentSeconds: Int64!
    
    var filesArray = [AVAudioFile?](repeating: nil, count: 6)
    
    let dispatchGroup = DispatchGroup()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        progressLoading.tintColor = .red
        progressLoading.progress = 0
        uploadingAudioLabel.isHidden = true
        goBackToStartButton.isEnabled = false
        playButton.isEnabled = false
        goBackToStartButton.alpha = 0.7
        playButton.alpha = 0.7
        
        view.isUserInteractionEnabled = false
        view.alpha = 0.5
        loadingProjectIndicator.alpha = 1.0
        
        view.sendSubviewToBack(collectionView)
        view.bringSubviewToFront(loadingProjectIndicator)
        loadingProjectIndicator.startAnimating()
        setupAudioEngine()
    }
    
    //MARK: VIEWDIDLOAD
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        print(projectKey ?? "")
        
        navigationController?.setNavigationBarHidden(true, animated: true)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.collectionViewLayout = flowLayout
        
        let itemSize = (view.frame.size.width / 3) - 20
        
        flowLayout.itemSize = CGSize(width: itemSize, height: itemSize)
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(cellTapped(_:)))
        collectionView.addGestureRecognizer(tapGestureRecognizer)
        
        setupKnobs()
        knobs = [knob1, knob2, knob3, knob4, knob5, knob6, knob7, knob8]
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.dispatchGroup.enter()
            self.queue.async {
                sleep(3)
                self.fetchAudioFile(indexPath: IndexPath(row: 0, section: 0))
                print("fetched 1")
                self.dispatchGroup.leave()
            }
            self.dispatchGroup.enter()
            self.queue.async {
                sleep(3)
                self.fetchAudioFile(indexPath: IndexPath(row: 1, section: 0))
                print("fetched 2")
                self.dispatchGroup.leave()
            }
            self.dispatchGroup.enter()
            self.queue.async {
                sleep(3)
                self.fetchAudioFile(indexPath: IndexPath(row: 2, section: 0))
                print("fetched 3")
                self.dispatchGroup.leave()
            }
            self.dispatchGroup.enter()
            self.queue.async {
                sleep(3)
                self.fetchAudioFile(indexPath: IndexPath(row: 3, section: 0))
                print("fetched 4")
                self.dispatchGroup.leave()
            }
            self.dispatchGroup.enter()
            self.queue.async {
                sleep(3)
                self.fetchAudioFile(indexPath: IndexPath(row: 4, section: 0))
                print("fetched 5")
                self.dispatchGroup.leave()
            }
            self.dispatchGroup.enter()
            self.queue.async {
                sleep(3)
                self.fetchAudioFile(indexPath: IndexPath(row: 5, section: 0))
                print("fetched 6")
                sleep(3)
                self.dispatchGroup.leave()
            }
            
            self.dispatchGroup.notify(queue: self.queue) {
                print("Fetched")
                DispatchQueue.main.async {
                    self.scheduleFiles()
                    self.goBackToStartButton.isEnabled = true
                    self.playButton.isEnabled = true
                    self.goBackToStartButton.alpha = 1.0
                    self.playButton.alpha = 1.0
                    self.view.isUserInteractionEnabled = true
                    self.view.alpha = 1.0
                    self.loadingProjectIndicator.stopAnimating()
                }
            }
        }
    }
    
    var index: IndexPath!
    
    //MARK: CELL TAPPED
    
    @objc func cellTapped(_ sender: UITapGestureRecognizer) {
        let pointInCollectionView = sender.location(in: collectionView)
        let indexPath = collectionView.indexPathForItem(at: pointInCollectionView)
        index = indexPath
        print(index ?? 0)
        if let indexPath = indexPath {
            trackName.text = "Track \(indexPath.row + 1)"
            
            if readValuesFromDatabase[indexPath.row] == false {
                let freq1 = (tracks[indexPath.row].eq?.freq1 ?? 20)
                let freq2 = (tracks[indexPath.row].eq?.freq2 ?? 401)
                let freq3 = (tracks[indexPath.row].eq?.freq3 ?? 2001)
                let freq4 = (tracks[indexPath.row].eq?.freq4 ?? 8001)
                let gain1 = (tracks[indexPath.row].eq?.gain1 ?? 0)
                let gain2 = (tracks[indexPath.row].eq?.gain2 ?? 0)
                let gain3 = (tracks[indexPath.row].eq?.gain3 ?? 0)
                let gain4 = (tracks[indexPath.row].eq?.gain4 ?? 0)
                
                self.equalizers[self.index.row]?.bands[0].frequency = freq1
                knob1.renderer.setPointerAngle(CGFloat(((freq1 - 20) / (400 - 20)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob1ValueLabel.text = "\(Int(freq1))"
                self.equalizers[self.index.row]?.bands[1].frequency = freq2
                knob2.renderer.setPointerAngle(CGFloat(((freq2 - 401) / (2000 - 401)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob2ValueLabel.text = "\(Int(freq2))"
                self.equalizers[self.index.row]?.bands[2].frequency = freq3
                knob3.renderer.setPointerAngle(CGFloat(((freq3 - 2001) / (8000 - 2001)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob3ValueLabel.text = "\(Int(freq3))"
                self.equalizers[self.index.row]?.bands[3].frequency = freq4
                knob4.renderer.setPointerAngle(CGFloat(((freq4 - 8001) / (20000 - 8001)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob4ValueLabel.text = "\(Int(freq4))"
                self.equalizers[self.index.row]?.bands[0].gain = gain1
                knob5.renderer.setPointerAngle(CGFloat(((gain1 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob5ValueLabel.text = "\(Int(gain1))"
                self.equalizers[self.index.row]?.bands[1].gain = gain2
                knob6.renderer.setPointerAngle(CGFloat(((gain2 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob6ValueLabel.text = "\(Int(gain2))"
                self.equalizers[self.index.row]?.bands[2].gain = gain3
                knob7.renderer.setPointerAngle(CGFloat(((gain3 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob7ValueLabel.text = "\(Int(gain3))"
                self.equalizers[self.index.row]?.bands[3].gain = gain4
                knob8.renderer.setPointerAngle(CGFloat(((gain4 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                knob8ValueLabel.text = "\(Int(gain4))"
                
                readValuesFromDatabase[indexPath.row] = true
            } else {
                
                values = []
                
                DispatchQueue.global(qos: .background).async {
                    self.projectRef.child("track\(indexPath.row)").observe(.value) { (snapshot) in
                        if let snapshots = snapshot.children.allObjects as? [DataSnapshot] {
                            for snap in snapshots {
                                self.values.append(snap.value)
                            }
                            let freq1 = (self.values[0] as? Float) ?? 20
                            let freq2 = (self.values[1] as? Float) ?? 401
                            let freq3 = (self.values[2] as? Float) ?? 2001
                            let freq4 = (self.values[3] as? Float) ?? 8001
                            let gain1 = (self.values[4] as? Float) ?? 0
                            let gain2 = (self.values[5] as? Float) ?? 0
                            let gain3 = (self.values[6] as? Float) ?? 0
                            let gain4 = (self.values[7] as? Float) ?? 0
                            DispatchQueue.main.async {
                                self.equalizers[self.index.row]?.bands[0].frequency = freq1
                                self.knob1.renderer.setPointerAngle(CGFloat(((freq1 - 20) / (400 - 20)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob1ValueLabel.text = "\(Int(freq1))"
                                self.equalizers[self.index.row]?.bands[1].frequency = freq2
                                self.knob2.renderer.setPointerAngle(CGFloat(((freq2 - 401) / (2000 - 401)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob2ValueLabel.text = "\(Int(freq2))"
                                self.equalizers[self.index.row]?.bands[2].frequency = freq3
                                self.knob3.renderer.setPointerAngle(CGFloat(((freq3 - 2001) / (8000 - 2001)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob3ValueLabel.text = "\(Int(freq3))"
                                self.equalizers[self.index.row]?.bands[3].frequency = freq4
                                self.knob4.renderer.setPointerAngle(CGFloat(((freq4 - 8001) / (20000 - 8001)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob4ValueLabel.text = "\(Int(freq4))"
                                self.equalizers[self.index.row]?.bands[0].gain = gain1
                                self.knob5.renderer.setPointerAngle(CGFloat(((gain1 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob5ValueLabel.text = "\(Int(gain1))"
                                self.equalizers[self.index.row]?.bands[1].gain = gain2
                                self.knob6.renderer.setPointerAngle(CGFloat(((gain2 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob6ValueLabel.text = "\(Int(gain2))"
                                self.equalizers[self.index.row]?.bands[2].gain = gain3
                                self.knob7.renderer.setPointerAngle(CGFloat(((gain3 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob7ValueLabel.text = "\(Int(gain3))"
                                self.equalizers[self.index.row]?.bands[3].gain = gain4
                                self.knob8.renderer.setPointerAngle(CGFloat(((gain4 - -96) / (24 - -96)) * (1.1780972450961724 - -4.319689898685965) + -4.319689898685965))
                                self.knob8ValueLabel.text = "\(Int(gain4))"
                            }
                        }
                    }
                }
            }
        } else {
            trackName.text = "Select a Track"
        }
    }
    
    var values = [Any?]()
    
    @IBAction func knob1ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[0].frequency = knob1.value
        projectRef.child("track\(index.row)").updateChildValues(["freq1" : knob1.value])
        knob1ValueLabel.text = "\(Int(knob1.value))"
        print(knob1.value)
    }
    
    @IBAction func knob2ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[1].frequency = knob2.value
        projectRef.child("track\(index.row)").updateChildValues(["freq2" : knob2.value])
        knob2ValueLabel.text = "\(Int(knob2.value))"
        print(knob2.value)
    }
    
    @IBAction func knob3ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[2].frequency = knob3.value
        projectRef.child("track\(index.row)").updateChildValues(["freq3" : knob3.value])
        knob3ValueLabel.text = "\(Int(knob3.value))"
        print(knob3.value)
    }
    
    
    @IBAction func knob4ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[3].frequency = knob4.value
        projectRef.child("track\(index.row)").updateChildValues(["freq4" : knob4.value])
        knob4ValueLabel.text = "\(Int(knob4.value))"
        print(knob4.value)
    }
    
    
    @IBAction func knob5ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[0].gain = knob5.value
        projectRef.child("track\(index.row)").updateChildValues(["gain1" : knob5.value])
        knob5ValueLabel.text = "\(Int(knob5.value))"
        print(knob5.value)
    }
    
    
    @IBAction func knob6ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[1].gain = knob6.value
        projectRef.child("track\(index.row)").updateChildValues(["gain2" : knob6.value])
        knob6ValueLabel.text = "\(Int(knob6.value))"
        print(knob6.value)
    }
    
    
    @IBAction func knob7ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[2].gain = knob7.value
        projectRef.child("track\(index.row)").updateChildValues(["gain3" : knob7.value])
        knob7ValueLabel.text = "\(Int(knob7.value))"
        print(knob7.value)
    }
    
    
    @IBAction func knob8ValueChanged(_ sender: Any) {
        guard let index = index else { return }
        self.equalizers[self.index.row]?.bands[3].gain = knob8.value
        projectRef.child("track\(index.row)").updateChildValues(["gain4" : knob8.value])
        knob8ValueLabel.text = "\(Int(knob8.value))"
        print(knob8.value)
    }
    
    func removeAudioPlayer(audioPlayer: AVAudioPlayerNode) {
        DispatchQueue.global(qos: .background).async {
            self.audioEngine.detach(audioPlayer)
            print("EQ's: \(String(describing: self.equalizers))")
            print("Track's: \(String(describing: self.audioPlayers))")
        }
    }
    
    func attachFiles(audioFile: URL) {
        let fileURL = audioFile
        
        var file: AVAudioFile!
        
        do {
            try file = AVAudioFile(forReading: (fileURL.absoluteURL))
            print(file.length)
            filesArray.remove(at: self.index.row)
            filesArray.insert(file, at: self.index.row)
            print("FILES: \(String(describing: filesArray))")
            scheduleFiles()
        } catch let error {
            print("File Error: \(error.localizedDescription)")
        }
    }
    
    func playTracks() {
        DispatchQueue.global(qos: .background).async {
            for audioPlayer in self.audioPlayers {
                audioPlayer?.play(at: nil)
                print("Playing")
            }
        }
    }
    
    func pauseAudioEngine() {
        audioEngine.pause()
        playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
    }
    
    @IBAction func playButtonTapped(_ sender: Any) {
        playButton.isSelected = !playButton.isSelected
        if playButton.isSelected {
            do {
                try audioEngine.start()
                let sampleTime = audioEngine.outputNode.lastRenderTime?.sampleTime
                let sampleRate = audioEngine.outputNode.outputFormat(forBus: 0).sampleRate
                startSeconds =  sampleTime! / AVAudioFramePosition(sampleRate)
                print(startSeconds ?? 0)
            } catch {
                print("Could not start audio engine")
            }
            playTracks()
            playButton.setBackgroundImage(UIImage(systemName: "stop"), for: .normal)
            playButton.isSelected = true
        } else {
            playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
            playButton.isSelected = false
            audioEngine.pause()
            
            for audioPlayer in audioPlayers {
                audioPlayer?.pause()
            }
        }
    }
    
    @IBAction func goBackButtonTapped(_ sender: Any) {
        DispatchQueue.global(qos: .background).async {
            self.audioEngine.stop()
            do {
                try self.audioEngine.start()
            } catch {
                print(error)
            }
            for audioPlayer in self.audioPlayers {
                audioPlayer?.stop()
            }
            self.scheduleFilesToStart()
            DispatchQueue.main.async {
                self.playButton.setBackgroundImage(UIImage(systemName: "play"), for: .normal)
                self.playButton.isSelected = false
            }
        }
    }
    
    //    @IBAction func timeSliderValueChanged(_ sender: Any) {
    //        if audioEngine.isRunning {
    //            let sampleTime = audioEngine.outputNode.lastRenderTime?.sampleTime
    //            let sampleRate = audioEngine.outputNode.outputFormat(forBus: 0).sampleRate
    //            currentSeconds =  sampleTime! / AVAudioFramePosition(sampleRate)
    //            print(currentSeconds ?? 0)
    //        }
    //    }
    
    func checkMuteTrack(cell: TrackCell) {
        if cell.isMuted == true {
            cell.muteDelegate?.muteButtonTapped(cell: cell)
            cell.audioPlayer?.volume = 0
            cell.muteButton.backgroundColor = .muteBlue
            cell.muteButton.tintColor = .muteBlue
            cell.volumeDelegate?.changeVolume(cell: cell, volume: cell.audioPlayer?.volume ?? 0)
        } else {
            cell.muteButton.isSelected = false
            cell.audioPlayer?.volume = cell.volumeSlider.value
            cell.muteButton.backgroundColor = .clear
            cell.muteButton.tintColor = .clear
            cell.volumeDelegate?.changeVolume(cell: cell, volume: cell.audioPlayer?.volume ?? 0)
        }
    }
    
}
